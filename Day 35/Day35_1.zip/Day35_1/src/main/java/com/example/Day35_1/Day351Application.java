package com.example.Day35_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day351Application {

	public static void main(String[] args) {
		SpringApplication.run(Day351Application.class, args);
	}

}
