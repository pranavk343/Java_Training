package com.example.Day35_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day352Application {

	public static void main(String[] args) {
		SpringApplication.run(Day352Application.class, args);
	}

}
