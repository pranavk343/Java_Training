package com.example.Day35_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day352ApplicationTests {

	@Test
	void contextLoads() {
	}

}
